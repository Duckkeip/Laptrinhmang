require('dotenv').config();

const path = require('path');
const fs = require('fs');
const http = require('http');
const express = require('express');
const multer = require('multer');
const { Server } = require('socket.io');
const { nanoid } = require('nanoid');

const { connectDB } = require('./db/connection');
const Room = require('./db/Room');
const Message = require('./db/Message');

const PORT = process.env.PORT || 3000;
const MONGODB_URI = process.env.MONGODB_URI || 'mongodb://127.0.0.1:27017/multiroom-chat';

// ---------- AI Bot config ----------
// URL cua service inference (xem ai_service/app.py) - noi model da finetune dang chay
const AI_SERVICE_URL = process.env.AI_SERVICE_URL || 'http://localhost:8000';
const AI_BOT_NAME = 'AI Bot';
// Nhan biet lenh goi AI: "/ai <cau hoi>" hoac chua "@AI <cau hoi>" o bat ky dau trong tin nhan
function extractAIPrompt(text) {
  const trimmed = text.trim();
  if (trimmed.toLowerCase().startsWith('/ai ')) {
    return trimmed.slice(4).trim();
  }
  const mentionMatch = trimmed.match(/@AI\b[:,]?\s*(.*)/i);
  if (mentionMatch) {
    return (mentionMatch[1] || '').trim() || trimmed.replace(/@AI\b[:,]?/i, '').trim();
  }
  return null;
}

// Goi service inference (model da finetune) va tra ve cau tra loi dang text
async function askAIBot(prompt, room, username) {
  const res = await fetch(`${AI_SERVICE_URL}/generate`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ prompt, room, username })
  });
  if (!res.ok) throw new Error(`AI service tra ve loi ${res.status}`);
  const data = await res.json();
  return data.reply || 'Xin loi, minh chua nghi ra cau tra loi.';
}
const PUBLIC_DIR = path.join(__dirname, 'public');
const UPLOAD_DIR = path.join(PUBLIC_DIR, 'uploads');

if (!fs.existsSync(UPLOAD_DIR)) fs.mkdirSync(UPLOAD_DIR, { recursive: true });

const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const User = require('./db/User');

const JWT_SECRET = process.env.JWT_SECRET ;
if (!process.env.JWT_SECRET) {
  console.warn('[CANH BAO] Chua dat JWT_SECRET trong .env, dang dung gia tri mac dinh KHONG AN TOAN cho production.');
}

// ---------- App & Server setup ----------
const app = express();
const server = http.createServer(app);
const io = new Server(server, {
  maxHttpBufferSize: 1e7 // 10MB, du phong cho socket payload
});

app.use(express.static(PUBLIC_DIR));
app.use(express.json());
// ---------- HTML Routes ----------
// Route mặc định: Chuyển hướng sang /login
app.get('/', (req, res) => {
  res.redirect('/login');
});

// Route render trang Login
app.get('/login', (req, res) => {
  res.sendFile(path.join(PUBLIC_DIR, 'login.html'));
});

// Route render trang Chat
app.get('/chat', (req, res) => {
  res.sendFile(path.join(PUBLIC_DIR, 'chat.html'));
});
// ---------- File upload (Multer) ----------
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, UPLOAD_DIR),
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname);
    const safeName = `${Date.now()}-${nanoid(8)}${ext}`;
    cb(null, safeName);
  }
});

const upload = multer({
  storage,
  limits: { fileSize: 15 * 1024 * 1024 }, // 15MB
  fileFilter: (req, file, cb) => {
    const allowed = /\.(jpg|jpeg|png|gif|webp|pdf|docx?|xlsx?|pptx?|txt|zip)$/i;
    if (!allowed.test(file.originalname)) {
      return cb(new Error('Dinh dang file khong duoc ho tro'));
    }
    cb(null, true);
  }
});

// Xac thuc JWT tu header "Authorization: Bearer <token>"
function verifyAuthHeader(req) {
  const header = req.headers.authorization || '';
  const [scheme, token] = header.split(' ');
  if (scheme !== 'Bearer' || !token) return null;
  try {
    return jwt.verify(token, JWT_SECRET); // { id, username, iat, exp }
  } catch (err) {
    return null;
  }
}

function requireAuth(req, res, next) {
  const decoded = verifyAuthHeader(req);
  if (!decoded) return res.status(401).json({ error: 'Chua dang nhap hoac phien da het han' });
  req.user = decoded;
  next();
}

app.post('/upload', requireAuth, upload.single('file'), (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'Khong co file' });
  const isImage = /\.(jpg|jpeg|png|gif|webp)$/i.test(req.file.originalname);
  res.json({
    url: `/uploads/${req.file.filename}`,
    name: req.file.originalname,
    size: req.file.size,
    isImage
  });
});

// Middleware bat loi tu Multer (vd file qua lon, sai dinh dang)
app.use((err, req, res, next) => {
  if (err) return res.status(400).json({ error: err.message });
  next();
});

// ----- API 1: Đăng ký -----
app.post('/api/register', async (req, res) => {
  try {
    const { username, password } = req.body;
    if (!username || !password) {
      return res.status(400).json({ error: 'Vui lòng nhập đầy đủ tên và mật khẩu' });
    }
    if (String(username).trim().length < 3) {
      return res.status(400).json({ error: 'Tên đăng nhập phải có ít nhất 3 ký tự' });
    }
    if (String(password).length < 6) {
      return res.status(400).json({ error: 'Mật khẩu phải có ít nhất 6 ký tự' });
    }

    const existingUser = await User.findOne({ username });
    if (existingUser) {
      return res.status(400).json({ error: 'Tên người dùng đã tồn tại' });
    }

    const hashedPassword = await bcrypt.hash(password, 10);
    const newUser = await User.create({ username, password: hashedPassword });

    const token = jwt.sign({ id: newUser._id, username: newUser.username }, JWT_SECRET, { expiresIn: '7d' });
    res.json({ ok: true, username: newUser.username, token });
  } catch (err) {
    res.status(500).json({ error: 'Lỗi máy chủ khi đăng ký' });
  }
});

// ----- API 2: Đăng nhập -----
app.post('/api/login', async (req, res) => {
  try {
    const { username, password } = req.body;
    const user = await User.findOne({ username });
    if (!user) {
      return res.status(400).json({ error: 'Tài khoản hoặc mật khẩu không đúng' });
    }

    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      return res.status(400).json({ error: 'Tài khoản hoặc mật khẩu không đúng' });
    }

    const token = jwt.sign({ id: user._id, username: user.username }, JWT_SECRET, { expiresIn: '7d' });
    res.json({ ok: true, username: user.username, token });
  } catch (err) {
    res.status(500).json({ error: 'Lỗi máy chủ khi đăng nhập' });
  }
});

// ---------- Persistence layer (MongoDB) ----------
const HISTORY_LIMIT = 200;
const DEFAULT_ROOMS = ['General', 'Random', 'Tech'];

// Doc N tin nhan gan nhat cua 1 phong, tra ve theo thu tu tang dan thoi gian
async function loadHistory(room) {
  const docs = await Message.find({ room })
    .sort({ time: -1 })
    .limit(HISTORY_LIMIT)
    .lean();
  return docs.reverse().map(toClientMessage);
}

async function appendHistory(room, message) {
  const doc = await Message.create({ room, ...message });
  return toClientMessage(doc.toObject ? doc.toObject() : doc);
}

// Chuyen doc Mongo (_id, __v...) thanh object gon nhe gui ve client
function toClientMessage(doc) {
  return {
    id: String(doc._id),
    type: doc.type,
    username: doc.username,
    text: doc.text,
    url: doc.url,
    name: doc.name,
    size: doc.size,
    isImage: doc.isImage,
    time: doc.time
  };
}

async function ensureDefaultRooms() {
  for (const name of DEFAULT_ROOMS) {
    await Room.updateOne({ name }, { $setOnInsert: { name } }, { upsert: true });
  }
}

async function loadRoomNamesFromDB() {
  const docs = await Room.find({}).sort({ createdAt: 1 }).lean();
  return docs.map(d => d.name);
}

async function createRoomInDB(name) {
  try {
    await Room.create({ name });
    return true;
  } catch (err) {
    if (err.code === 11000) return false; // phong da ton tai
    throw err;
  }
}

// ---------- In-memory presence state (khong can luu DB) ----------
// socket.id -> { username, room }
const users = new Map();
// roomName -> Set<socket.id>  (chi de theo doi ai dang online, khong phai nguon su that ve phong)
const rooms = new Map();

function ensureRoomTracked(room) {
  if (!rooms.has(room)) rooms.set(room, new Set());
}

function getRoomList() {
  return Array.from(rooms.keys()).map(name => ({
    name,
    online: rooms.get(name).size
  }));
}

function getOnlineUsers(room) {
  const socketIds = rooms.get(room) || new Set();
  return Array.from(socketIds)
    .map(id => users.get(id)?.username)
    .filter(Boolean);
}

function broadcastRoomList() {
  io.emit('room-list', getRoomList());
}

function broadcastOnlineUsers(room) {
  io.to(room).emit('online-users', getOnlineUsers(room));
}

// ---------- Socket.io ----------
// Moi ket noi socket bat buoc phai co JWT hop le (lay tu handshake.auth.token).
// Neu khong co / het han / sai chu ky -> tu choi ket noi ngay tu dau.
io.use((socket, next) => {
  const token = socket.handshake.auth && socket.handshake.auth.token;
  if (!token) return next(new Error('AUTH_REQUIRED'));
  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    socket.user = { id: decoded.id, username: decoded.username };
    next();
  } catch (err) {
    next(new Error('AUTH_INVALID'));
  }
});

io.on('connection', socket => {
  socket.emit('room-list', getRoomList());

  socket.on('join', async ({ room }, ack) => {
    try {
      // Username khong con lay tu client nua - dung dung username da duoc
      // xac thuc trong JWT de tranh gia mao ten nguoi khac.
      const username = socket.user.username;
      room = String(room || 'General').trim().slice(0, 30) || 'General';

      // Dam bao phong ton tai trong DB (vd nguoi dung go thang ten phong moi)
      await createRoomInDB(room).catch(() => {});
      ensureRoomTracked(room);

      // Neu socket dang o phong khac, roi phong cu truoc
      const prev = users.get(socket.id);
      if (prev && prev.room && prev.room !== room) {
        leaveRoom(socket, prev.room, prev.username);
      }

      socket.join(room);
      rooms.get(room).add(socket.id);
      users.set(socket.id, { username, room });

      const history = await loadHistory(room);

      if (typeof ack === 'function') {
        ack({ ok: true, username, room, history });
      }

      socket.to(room).emit('system-message', {
        type: 'join',
        text: `${username} da tham gia phong`,
        time: Date.now()
      });

      broadcastOnlineUsers(room);
      broadcastRoomList();
    } catch (err) {
      console.error('Loi khi join phong:', err);
      if (typeof ack === 'function') ack({ ok: false, error: 'Loi server, thu lai sau' });
    }
  });

  socket.on('chat-message', async ({ text }) => {
    try {
      const user = users.get(socket.id);
      if (!user || !text || !text.trim()) return;

      const saved = await appendHistory(user.room, {
        type: 'text',
        username: user.username,
        text: text.trim().slice(0, 2000),
        time: Date.now()
      });

      io.to(user.room).emit('chat-message', saved);

      // Neu tin nhan la lenh goi AI Bot (/ai ... hoac @AI ...), goi model
      // da finetune de sinh cau tra loi, roi phat no nhu 1 tin nhan binh
      // thuong tu user "AI Bot" trong cung phong.
      const aiPrompt = extractAIPrompt(saved.text);
      if (aiPrompt) {
        io.to(user.room).emit('typing', { username: AI_BOT_NAME, isTyping: true });
        try {
          const reply = await askAIBot(aiPrompt, user.room, user.username);
          const aiSaved = await appendHistory(user.room, {
            type: 'text',
            username: AI_BOT_NAME,
            text: reply.slice(0, 2000),
            time: Date.now()
          });
          io.to(user.room).emit('chat-message', aiSaved);
        } catch (err) {
          console.error('Loi khi goi AI service:', err.message);
          io.to(user.room).emit('system-message', {
            type: 'error',
            text: 'AI Bot dang gap su co, thu lai sau.',
            time: Date.now()
          });
        } finally {
          io.to(user.room).emit('typing', { username: AI_BOT_NAME, isTyping: false });
        }
      }
    } catch (err) {
      console.error('Loi khi luu tin nhan:', err);
    }
  });

  socket.on('file-message', async ({ url, name, size, isImage }) => {
    try {
      const user = users.get(socket.id);
      if (!user || !url) return;

      const saved = await appendHistory(user.room, {
        type: 'file',
        username: user.username,
        url,
        name,
        size,
        isImage: !!isImage,
        time: Date.now()
      });

      io.to(user.room).emit('chat-message', saved);
    } catch (err) {
      console.error('Loi khi luu file message:', err);
    }
  });

  socket.on('typing', isTyping => {
    const user = users.get(socket.id);
    if (!user) return;
    socket.to(user.room).emit('typing', {
      username: user.username,
      isTyping: !!isTyping
    });
  });

  socket.on('create-room', async (roomName, ack) => {
    try {
      roomName = String(roomName || '').trim().slice(0, 30);
      if (!roomName) {
        if (ack) ack({ ok: false, error: 'Ten phong khong hop le' });
        return;
      }

      const created = await createRoomInDB(roomName);
      ensureRoomTracked(roomName);
      if (created) broadcastRoomList();

      if (ack) ack({ ok: true });
    } catch (err) {
      console.error('Loi khi tao phong:', err);
      if (ack) ack({ ok: false, error: 'Loi server, thu lai sau' });
    }
  });

  socket.on('disconnect', () => {
    const user = users.get(socket.id);
    if (!user) return;
    leaveRoom(socket, user.room, user.username);
    users.delete(socket.id);
  });

  function leaveRoom(sock, room, username) {
    sock.leave(room);
    const set = rooms.get(room);
    if (set) {
      set.delete(sock.id);
      sock.to(room).emit('system-message', {
        type: 'leave',
        text: `${username} da roi phong`,
        time: Date.now()
      });
      broadcastOnlineUsers(room);
      broadcastRoomList();
    }
  }
});

// ---------- Khoi dong: ket noi DB truoc, roi moi mo cong lang nghe ----------
async function main() {
  try {
    await connectDB(MONGODB_URI);
    await ensureDefaultRooms();

    const roomNames = await loadRoomNamesFromDB();
    roomNames.forEach(ensureRoomTracked);

    server.listen(PORT, () => {
      console.log(`Multi-room chat server dang chay tai http://localhost:${PORT}`);
    });
  } catch (err) {
    console.error('Khong the ket noi MongoDB:', err.message);
    console.error(`Kiem tra bien moi truong MONGODB_URI (hien tai: ${MONGODB_URI})`);
    process.exit(1);
  }
}

main();